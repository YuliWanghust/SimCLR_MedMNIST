def summarise():
    print("Done! :)")
